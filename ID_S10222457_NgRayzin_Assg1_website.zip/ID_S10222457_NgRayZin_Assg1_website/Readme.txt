YOASOBI website
This project is a band website where it covers the band, YOASOBI, songs, 
profile, performances and merch. This website is made for YOASOBI fans 
and other gigs. My goal is to get income by trying to impress gigs and 
get a sponsor and for fans/listeners to buy the merch and to get
more people to be interested in YOASOBI. This website is
filled with information and interactions that it will keep users interested.

As a user type, i want to This website to be as user friendly as 
possible. To achieve that, I made the theme a nice beige and red to give
off a comfortable vibe. I have also added an animated background
to make it more lively. There are interactions in the website 
so that the user could enjoy and explore the website, 
making them stay for a longer time.

As a sponser view, I am looking out for what this band did and how good their
songs are. This website shows exactly that. There is a profile page and song page
that showcases all the band's work and 

Every page have at least an interaction examples like a hover 
dropdown information.The most notable function of my website is 
the shoppingcart in my merch page. To purchase an item, users just have to
push a add to cart button and it wilk be there. Users can remove, add, subtract
items from the cart.

Other features i would like is a working searchbar. I did try to code it out, however,
it does not synergize with my shopping cart code and the codes effect each other.
If I had more time, I could have code the search bar in a different apporach.

I have use java script to do some of my functions like the shopping cart.

...........credits.....................
i received insipration from YOASOBI main website:https://www.yoasobi-music.jp/

content for the performaces and background information was used from
:https://www.yoasobi-music.jp/

image credits:
https://www.uniqlo.com/sg/en/spl/ut/yoasobi
https://www.yoasobi-music.jp/
https://www.japan-walker.net/hk/articles/2968
https://www.yoasobi-music.jp/song/

